package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;
import entity.NhanVien;
import entity.TaiKhoan;

public class TaiKhoan_Dao {
	ArrayList<TaiKhoan> dstk;
	TaiKhoan tk;
	public TaiKhoan_Dao() {
		dstk = new ArrayList<TaiKhoan>();
		tk = new TaiKhoan();
	}
	public ArrayList<TaiKhoan> getalltbTaiKhoan(){
		try {
			ConnectDB.getInstance();
			Connection con = ConnectDB.getConnection();
			
			String sql = "select * from TaiKhoan";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next()) {
				String tenTK = rs.getString(1);
				String matKhau = rs.getString(2);
				NhanVien nvien = new NhanVien(rs.getString(3));
				TaiKhoan s = new TaiKhoan(tenTK, matKhau, nvien);
				dstk.add(s);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return dstk;
	}
	
	public ArrayList<TaiKhoan> getTaiKhoanTheoNhanVien(String maNV){
		ArrayList<TaiKhoan> dstk = new ArrayList<TaiKhoan>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		PreparedStatement statement = null;
		try {
			String sql = "Select * from TaiKhoan where maNV=?";
			statement = con.prepareStatement(sql);
			statement.setString(1, maNV);
			
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next()) {
				String tenTK = rs.getString(1);
				String matKhau = rs.getString(2);
				NhanVien nvien = new NhanVien(rs.getString(3));
				TaiKhoan s = new TaiKhoan(tenTK, matKhau, nvien);
				dstk.add(s);
			}
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dstk;
	}
	
	public boolean create(TaiKhoan tk) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("insert into TaiKhoan values(?,?,?)");
			stmt.setString(1, tk.getTenTK());
			stmt.setString(2, tk.getMatKhau());
			stmt.setString(3, tk.getNhanVien().getMaNV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n >0;
	}
	
	public boolean update(TaiKhoan tk) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update TaiKhoan set tenTK=?, matkhau=? where maNV=?");
			stmt.setString(1, tk.getTenTK());
			stmt.setString(2, tk.getMatKhau());
			stmt.setString(3, tk.getNhanVien().getMaNV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return n>0;
		
	}
	public boolean delete(String maNV) {
		// TODO Auto-generated method stub
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from TaiKhoan where maNV = ?");
			stmt.setString(1, maNV);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
		
}

package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;

import entity.ChucVu;
import entity.DichVu;
import entity.LoaiDichVu;
import entity.NhanVien;

public class DichVu_Dao {
	public ArrayList<DichVu> getalltbDichVu () {
		ArrayList<DichVu> dsdv = new ArrayList<DichVu>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		try {
			String sql = "select * from DichVu where  maDV != 'DV000' " ;
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				String maDV = rs.getString(1);
				String tenDV = rs.getString(2);
				String donViTinh = rs.getString(3);
				double giaDV = rs.getDouble(4);
				LoaiDichVu dvu = new LoaiDichVu(rs.getString(5));
				DichVu s = new DichVu(maDV, tenDV, donViTinh, giaDV, dvu);
				dsdv.add(s);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dsdv;
	}
	
	public ArrayList<DichVu> getDichVuTheoLoaiDichVu(String loaiDV){
		ArrayList<DichVu> dsdv = new ArrayList<DichVu>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		PreparedStatement statement = null;
		try {
			String sql = "Select * from DichVu where loaiDV=?";
			statement = con.prepareStatement(sql);
			statement.setString(1, loaiDV);
			
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				String maDV = rs.getString(1);
				String tenDV = rs.getString(2);
				String donViTinh = rs.getString(3);
				double giaDV = rs.getDouble(4);
				LoaiDichVu dvu = new LoaiDichVu(rs.getString(5));
				DichVu s = new DichVu(maDV, tenDV, donViTinh, giaDV, dvu);
				dsdv.add(s);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return dsdv;
	}
//=======================
	public boolean update(DichVu dv) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update DichVu set tenDV=?, donViTinh=?, giaDV=?, loaiDV=? where maDV=?");
			stmt.setString(1, dv.getTenDV());
			stmt.setString(2, dv.getDonViTinh());
			stmt.setDouble(3, dv.getGiaDV());
			stmt.setString(4, dv.getDv().getLoaiDV());
			stmt.setString(5, dv.getMaDV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return n>0;
	}
//==========================
	public boolean create(DichVu dv) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("insert into DichVu values(?, ?, ?, ?, ?)");
			stmt.setString(1, dv.getMaDV());
			stmt.setString(2, dv.getTenDV());
			stmt.setString(3, dv.getDonViTinh());
			stmt.setDouble(4, dv.getGiaDV());
			stmt.setString(5, dv.getDv().getLoaiDV());
			
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return n>0;
	}
	public boolean delete(String maDV) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("delete from DichVu where maDV = ?");
			stmt.setString(1, maDV);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		return n >0;
	}

	public static ResultSet GetAll(){
        String sql="SELECT * FROM DichVu";        
        return ConnectDB.GetData(sql);
    }
    
    public static ResultSet Search(String loaiDV,String keyword ){
        String sql="SELECT * FROM DichVu where "
                + "(maDV  like N'%"  + keyword 
                + "%' or tenDV like N'%" + keyword + "%' or '' = '" + keyword 
                + "') and (loaiDV  = " + loaiDV + " or 0 = " + loaiDV + ")";        
        return ConnectDB.GetData(sql);
    }}

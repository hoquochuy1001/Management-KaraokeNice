package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class DoanhThu_Dao {
	String connect = "jdbc:sqlserver://localhost:1433;databasename=QuanLyKaraokeNice;user=sa;password=123";
	DefaultTableModel tbModel=new DefaultTableModel();
	
	public DefaultTableModel loadDt(String time)
	{
	try {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection(connect);
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select ngayTaoHD, SUM(TongTien) as HoaDon from HoaDon where ngayTaoHD='"+time+"' group by ngayTaoHD");
			String[] tieudecot = {"Thời gian","Doanh thu"};
			ArrayList<String[]> dulieubang = new ArrayList<String[]>();
			while(rs.next())
			{
				String[] dong = new String[2];
				dong[0] = rs.getString("ngayTaoHD");
				dong[1] = rs.getString("HoaDon");
				dulieubang.add(dong);
			}
			String[][] data = new String[dulieubang.size()][2];
			for(int i=0; i<dulieubang.size(); i++)
			{
				data[i]=dulieubang.get(i);
			}
			tbModel.setDataVector(data,tieudecot);
			return tbModel;
		}catch(Exception ex){
			JOptionPane.showMessageDialog(null, "Lỗi khi load Nv"+ex.toString());
			return null;
		}
	}

	public DefaultTableModel loadDtFor(String chonHt)
	{
	try {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection(connect);
		Statement st = con.createStatement();
		ArrayList<String[]> dulieubang = new ArrayList<String[]>();
		if(chonHt=="1")
		{
			ResultSet rs = st.executeQuery("select ngayTaoHD, SUM(TongTien) as HoaDon from HoaDon group by ngayTaoHD");
			while(rs.next())
			{
				String[] dong = new String[2];
				dong[0] = rs.getString("ngayTaoHD");
				dong[1] = rs.getString("HoaDon");
				dulieubang.add(dong);
			}
			String[] tieudecot = {"Thời gian","Doanh thu"};
			String[][] data = new String[dulieubang.size()][2];
			for(int i=0; i<dulieubang.size(); i++)
			{
				data[i]=dulieubang.get(i);
			}
			tbModel.setDataVector(data,tieudecot);
		}
		else if(chonHt == "2")
		{
			ResultSet rs = st.executeQuery("select year(ngayTaoHD) as nam, month(ngayTaoHD) as thang, sum(TongTien) as HoaDon from HoaDon group by year(ngayTaoHD),month(ngayTaoHD)");
			while(rs.next())
			{
				String[] dong = new String[3];
				dong[0] = rs.getString("nam");
				dong[1] = rs.getString("thang");
				dong[2] = rs.getString("HoaDon");
				dulieubang.add(dong);
			}
			String[] tieudecot = {"Năm", "Tháng", "Doanh thu"};
			String[][] data = new String[dulieubang.size()][3];
			for(int i=0; i<dulieubang.size(); i++)
			{
				data[i]=dulieubang.get(i);
			}
			tbModel.setDataVector(data,tieudecot);
		}
		else
		{
			ResultSet rs = st.executeQuery("select year(ngayTaoHD)as nam, sum(TongTien) as HoaDon from HoaDon group by year(ngayTaoHD)");
			while(rs.next())
			{
				String[] dong = new String[2];
				dong[0] = rs.getString("nam");
				dong[1] = rs.getString("HoaDon");
				dulieubang.add(dong);
			}
			String[] tieudecot = {"Năm","Doanh thu"};
			String[][] data = new String[dulieubang.size()][2];
			for(int i=0; i<dulieubang.size(); i++)
			{
				data[i]=dulieubang.get(i);
			}
			tbModel.setDataVector(data,tieudecot);
		}
			return tbModel;
	}
	catch(Exception ex){
		JOptionPane.showMessageDialog(null, "Lỗi khi load Nv"+ex.toString());
		return null;
	}
	}
	
}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;
import entity.LoaiDichVu;

public class LoaiDichVu_Dao {
	private String loaiDV;
	public ArrayList<LoaiDichVu> getalltbLoaiDichVu () {
		ArrayList<LoaiDichVu> s = new ArrayList<LoaiDichVu>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		try {
			String sql = "select * from LoaiDichVu" ;
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				s.add(new LoaiDichVu(rs.getString("loaiDV")));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	public boolean create(LoaiDichVu ldv) {
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("insert into LoaiDichVu values(?)");
			stmt.setString(1, ldv.getLoaiDV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}	
	public boolean delete(String ldv) {
		// TODO Auto-generated method stub
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from LoaiDichVu where loaiDV = ?");
			stmt.setString(1, ldv);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
	public static ResultSet GetAll() {
        String cauTruyVan = "Select * from LoaiDichVu order by loaiDV";
        return ConnectDB.GetData(cauTruyVan);
    }
}

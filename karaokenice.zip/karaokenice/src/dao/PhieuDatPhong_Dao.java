package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import connectDB.ConnectDB;
import entity.KhachHang;
import entity.LoaiPhong;
import entity.NhanVien;
import entity.PhieuDatPhong;
import entity.Phong;

public class PhieuDatPhong_Dao {
	private PhieuDatPhong p;
	private ArrayList<PhieuDatPhong> dsdp;
	
	public PhieuDatPhong_Dao() {
		dsdp = new ArrayList<PhieuDatPhong>();
		p = new PhieuDatPhong();
	}
	
	public List<PhieuDatPhong> getallPhieuDatPhong(){
		try {
			ConnectDB.getInstance();
			Connection con = ConnectDB.getConnection();
			String sql = "select maPDP,tenPhong,loaiPhong,giaPhong,tgDatPhong,maKH,maNV from PhieuDatPhong pdp join Phong p on pdp.maPhong = p.maPhong ";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next()) {
				int maPDP = rs.getInt("maPDP");

				Phong p = new Phong(rs.getString("tenPhong")
						,new LoaiPhong(rs.getString("loaiPhong")),rs.getDouble("giaPhong"));
				
				Date tgDatPhong = rs.getDate("tgDatPhong");
				
				KhachHang kh = new KhachHang(rs.getString("maKH"));
				
				NhanVien nv = new NhanVien(rs.getString("maNV"));
			
				PhieuDatPhong pdp = new PhieuDatPhong(maPDP, p, tgDatPhong, kh, nv);
				dsdp.add(pdp);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return dsdp;
	}
	public boolean delete(int xoa) {
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from PhieuDatPhong where maPDP = ?");
			stmt.setInt(1, xoa);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
}

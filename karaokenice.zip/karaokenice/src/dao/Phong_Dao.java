package dao;

import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;
import entity.ChucVu;
import entity.LoaiPhong;
import entity.NhanVien;
import entity.Phong;

public class Phong_Dao {
	public ArrayList<Phong> getallPhong(){
		ArrayList<Phong> dsphong = new ArrayList<Phong>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		try {
			String sql = "select * from Phong" ;
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				String maPhong = rs.getString(1);
				String tenPhong = rs.getString(2);
				
				double giaPhong = rs.getDouble(3);
				LoaiPhong lp = new LoaiPhong(rs.getString(4));
				String tinhTrang = rs.getString(5);
				
				Phong s = new Phong(maPhong, tenPhong, giaPhong, lp, tinhTrang);
				dsphong.add(s);
				
				
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return dsphong;
	}
	
	public ArrayList<Phong> getPhongTheoLoaiPhong(String loaiPhong){
		ArrayList<Phong> dsp = new ArrayList<Phong>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		PreparedStatement statement = null;
		try {
			String sql = "Select * from Phong where loaiPhong = ?";
			statement = con.prepareStatement(sql);
			statement.setString(1, loaiPhong);
			
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				String maPhong = rs.getString(1);
				String tenPhong = rs.getString(2);
				double giaPhong = rs.getDouble(3);
				LoaiPhong lp = new LoaiPhong(rs.getString(4));
				String tinhTrang = rs.getString(5);
				
				Phong s = new Phong(maPhong, tenPhong, giaPhong, lp, tinhTrang);
				dsp.add(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dsp;
	}
	
	public boolean create(Phong p) {
		int n= 0;
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("insert into Phong values(?, ?, ?, ?, ?)");
			stmt.setString(1, p.getMaPhong());
			stmt.setString(2, p.getTenPhong());
			stmt.setDouble(3, p.getGiaPhong());
			stmt.setString(4, p.getLoaiPhong().getLoaiPhong());
			stmt.setString(5, p.getTinhTrang());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
	
	public boolean update(Phong p) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update Phong set tenPhong=?, giaPhong=?, loaiPhong=?, tinhTrang=? where maPhong=?");
			stmt.setString(1, p.getTenPhong());
			stmt.setDouble(2, p.getGiaPhong());
			stmt.setString(3, p.getLoaiPhong().getLoaiPhong());
			stmt.setString(4, p.getTinhTrang());
			stmt.setString(5, p.getMaPhong());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return n>0;
		
	}
	
	public boolean delete(String maPhong) {
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from Phong where maPhong = ?");
			stmt.setString(1, maPhong);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
	
	public boolean updateTrangThaiDP(String u) {
		int n = 0;
		Connection con = ConnectDB.getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update Phong set tinhTrang = 'Phòng có Khách' where maPhong = ?");
			stmt.setString(1, u);
			n = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n>0;
	}
	public boolean updateTrangThaiTP(String u) {
		int n = 0;
		Connection con = ConnectDB.getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update Phong set tinhTrang = N'Phòng trống' where tenPhong = ?");
			stmt.setString(1, u);
			n = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n>0;
	}
	
}

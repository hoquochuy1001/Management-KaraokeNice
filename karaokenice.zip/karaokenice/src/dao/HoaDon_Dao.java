package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import bll.ChuyenDoi;
import connectDB.ConnectDB;
import entity.HoaDon;

public class HoaDon_Dao {
	 public static ResultSet CountSoHoaDon(String SoHoaDon) {
	        String cauTruyVan = "select Count(*) from HoaDon where SoHoaDon like N'%" + SoHoaDon + "%'";
	        return ConnectDB.GetData(cauTruyVan);
	    }
	    
	    //7 Hàm lấy theo SoHoaDon
	    public static ResultSet GetBySoHoaDon(String SoHoaDon) {
	        String cauTruyVan = "select * from HoaDon where SoHoaDon = N'" + SoHoaDon + "'";
	        return ConnectDB.GetData(cauTruyVan);
	    }
}

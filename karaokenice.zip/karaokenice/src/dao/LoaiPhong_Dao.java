package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;
import entity.LoaiPhong;

public class LoaiPhong_Dao {
	private String loaiPhong;
	public ArrayList<LoaiPhong> getalltbLoaiPhong () {
		ArrayList<LoaiPhong> s = new ArrayList<LoaiPhong>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		try {
			String sql = "select * from LoaiPhong" ;
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				s.add(new LoaiPhong(rs.getString("loaiPhong")));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	public boolean create(LoaiPhong lp) {
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("insert into LoaiPhong values(?)");
			stmt.setString(1, lp.getLoaiPhong());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}	
	public boolean delete(String lp) {
		// TODO Auto-generated method stub
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from LoaiPhong where loaiPhong = ?");
			stmt.setString(1, lp);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;

import entity.KhachHang;

public class KhachHang_Dao {
	private String maKH;
	private String tenKH;
	private String cmnd;
	private String sdt;
	public ArrayList<KhachHang> getalltbKhachHang () {
		ArrayList<KhachHang> dskh = new ArrayList<KhachHang>();
		Connection con = ConnectDB.getInstance().getConnection();
		try {
			String sql = "select * from KhachHang" ;
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				dskh.add(new KhachHang(rs.getString("maKH"), rs.getString("tenKH"), rs.getString("cmnd"), rs.getString("sdt"))) ;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dskh;
	}
	public boolean create(KhachHang kh) {
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("insert into KhachHang values(?, ?, ?, ?)");
			stmt.setString(1, kh.getMaKH());
			stmt.setString(2, kh.getTenKH());
			stmt.setString(3, kh.getCmnd());
			stmt.setString(4, kh.getSdt());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}	
	public boolean update(KhachHang kh) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update KhachHang set tenKH=?, cmnd=?, sdt=? where maKH=?");
			stmt.setString(1, kh.getTenKH());
			stmt.setString(2, kh.getCmnd());
			stmt.setString(3, kh.getSdt());
			stmt.setString(4, kh.getMaKH());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return n>0;
		
	}
	public boolean delete(String maKH) {
		// TODO Auto-generated method stub
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from KhachHang where maKH = ?");
			stmt.setString(1, maKH);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
	public static ResultSet GetAll() {
        String cauTruyVan = "Select * from KhachHang order by tenKH";
        return ConnectDB.GetData(cauTruyVan);
    }
    
    public static  ResultSet GetByMaKH(String MaKH){
        String cauTruyVan = "Select * from KhachHang where maKH = " + MaKH;
        return ConnectDB.GetData(cauTruyVan);
    }
    
    public static  ResultSet GetByKeyword(String keyword){
        String cauTruyVan = "Select * from KhachHang where maKH like '%" + keyword + "%'  or " 
                + " tenKH like N'%" + keyword + "%'";
        return ConnectDB.GetData(cauTruyVan);
    }
}

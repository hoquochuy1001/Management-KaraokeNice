package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;
import entity.ChucVu;
import entity.KhachHang;
import entity.NhanVien;

public class NhanVien_Dao {
	ArrayList<NhanVien> dsnv;
	NhanVien nv;
	public NhanVien_Dao() {
		dsnv = new ArrayList<NhanVien>();
		nv = new NhanVien();
	}
	public ArrayList<NhanVien> getalltbNhanVien(){
		try {
			ConnectDB.getInstance();
			Connection con = ConnectDB.getConnection();
			
			String sql = "select * from NhanVien";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next()) {
				String maNV = rs.getString(1);
				String tenNV = rs.getString(2);
				Date ngaySinh = rs.getDate(3);
				String sdt = rs.getString(4);
				String gioiTinh = rs.getString(5);
				ChucVu cvu = new ChucVu(rs.getString(6));
				NhanVien s = new NhanVien(maNV, tenNV, ngaySinh, sdt, gioiTinh, cvu);
				dsnv.add(s);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return dsnv;
	}
	
	public ArrayList<NhanVien> getNhanVienTheoChucVu(String maCV){
		ArrayList<NhanVien> dsnv = new ArrayList<NhanVien>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		PreparedStatement statement = null;
		try {
			String sql = "Select * from NhanVien where maCV=? ";
			statement = con.prepareStatement(sql);
			statement.setString(1, maCV);
			
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next()) {
				String maNV = rs.getString(1);
				String tenNV = rs.getString(2);
				Date ngaySinh = rs.getDate(3);
				String sdt = rs.getString(4);
				String gioiTinh = rs.getString(5);
				ChucVu cvu = new ChucVu(rs.getString(6));
				
				NhanVien nv = new NhanVien(maNV, tenNV, ngaySinh, sdt, gioiTinh, cvu);
				dsnv.add(nv);
			}
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dsnv;
	}
	public boolean update(NhanVien nv) {
		int n = 0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update NhanVien set tenNV=?, ngaySinh=?, sdt=?, gioiTinh=?, maCV=? where maNV=?");
			stmt.setString(1, nv.getTenNV());
			stmt.setDate(2, nv.getNgaysinh());
			stmt.setString(3, nv.getSdt());
			stmt.setString(4, nv.getGioiTinh());
			stmt.setString(5, nv.getChucvu().getMaCV());
			stmt.setString(6, nv.getMaNV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return n>0;
		
	}
	
	public boolean create(NhanVien nv) {
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("insert into NhanVien values(?, ?, ?, ?, ?, ?)");
			stmt.setString(1, nv.getMaNV());
			stmt.setString(2, nv.getTenNV());
			stmt.setDate(3, nv.getNgaysinh());
			stmt.setString(4, nv.getSdt());
			stmt.setString(5, nv.getGioiTinh());
			stmt.setString(6, nv.getChucvu().getMaCV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
	public boolean delete(String maNV) {
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from NhanVien where maNV = ?");
			stmt.setString(1, maNV);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
	public ArrayList<NhanVien> getalltbNhanVien1(){
		try {
			ConnectDB.getInstance();
			Connection con = ConnectDB.getConnection();
			
			String sql = "select * from NhanVien where  maNV != 'NV001'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next()) {
				String maNV = rs.getString(1);
				String tenNV = rs.getString(2);
				Date ngaySinh = rs.getDate(3);
				String sdt = rs.getString(4);
				String gioiTinh = rs.getString(5);
				ChucVu cvu = new ChucVu(rs.getString(6));
				NhanVien s = new NhanVien(maNV, tenNV, ngaySinh, sdt, gioiTinh, cvu);
				dsnv.add(s);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return dsnv;
	}
}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connectDB.ConnectDB;
import entity.ChucVu;

public class ChucVu_Dao {
	public ArrayList<ChucVu> getalltbChucVu () {
		ArrayList<ChucVu> dsphong = new ArrayList<ChucVu>();
		ConnectDB.getInstance();
		Connection con = ConnectDB.getConnection();
		try {
			String sql = "select * from ChucVu" ;
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				//dsphong.add(new ChucVu(rs.getString("maCV"), rs.getString("tenCV"))) ;
				String maCV = rs.getString(1);
				String tenCV = rs.getString(2);
				ChucVu c = new ChucVu(maCV, tenCV);
				dsphong.add(c);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dsphong;
	}
	public boolean create(ChucVu cv) {
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("insert into ChucVu values(?, ?)");
			stmt.setString(1, cv.getMaCV());
			stmt.setString(2, cv.getTenCV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}	
	public boolean update(ChucVu cv) {
		int n =0;
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement("update ChucVu set tenCV=? where maCV=?");
			stmt.setString(1, cv.getTenCV());
			stmt.setString(2, cv.getMaCV());
			n = stmt.executeUpdate();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
	public boolean delete(String maCV) {
		// TODO Auto-generated method stub
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		try {
			stmt = con.prepareStatement("delete from ChucVu where maCV = ?");
			stmt.setString(1, maCV);
			n = stmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return n>0;
	}
}

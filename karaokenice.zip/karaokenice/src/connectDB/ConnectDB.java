package connectDB;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import java.sql.*;

public class ConnectDB {
	public static Connection con = null;
	public static ConnectDB instance = new ConnectDB();
	
	public static ConnectDB getInstance() {
		return instance;
	}
	public static void setInstance(ConnectDB instance) {
		ConnectDB.instance = instance;
	}
	
	public void connect() {
		String url = "jdbc:sqlserver://localhost:1433;databasename=QuanLyKaraokeNice";
		String user = "sa";
		String password = "123";
		try {
			con = DriverManager.getConnection(url,user,password);
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(Connection con) {
		try {
			if (con!=null)
				con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() {
		return con;
	}
	public static ResultSet GetData(String cauTruyVan){
        try {
            Statement stm = con.createStatement();           
            ResultSet rs = stm.executeQuery(cauTruyVan);
            
            return rs;
            
        } catch (SQLException ex) {
            System.out.println("Lỗi lấy dữ liệu");
            return null; 
        }
    }
    //Hàm thực hiện 3 lệnh Insert, Update, Delete
    public static int ExecuteTruyVan(String cauTruyVan){
        try {
            Statement stm = con.createStatement();
            int kq = stm.executeUpdate(cauTruyVan);
            return kq;
        } catch (SQLException ex) {
            System.out.println("Lỗi thực thi lệnh SQL");
            return -1;
        }        
    }
}

package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import javax.swing.JComboBox;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.border.BevelBorder;
import javax.swing.JTabbedPane;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.Component;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import org.jfree.ui.about.SystemPropertiesTableModel;

import connectDB.ConnectDB;
import dao.DichVu_Dao;
import dao.Phong_Dao;
import entity.DichVu;
import entity.Phong;

public class TimKiemPhong_GUI extends JFrame implements ActionListener,MouseListener{

	private JPanel contentPane;
	private JTextField textField_tenPhong;
	private JTable table;
	private JComboBox comboBox_loaiPhong;
	private JComboBox comboBox_tinhTrang;
	private DefaultTableModel tableModel;
	private Component btnNewButton;
//	private Component textField;
//	private Phong_Dao Phong_Dao;
	private dao.Phong_Dao p_dao;
	private JButton btnNewButton_find;
	private JButton btnNewButton_find_1;
	private JButton btnNewButton_find_2;
	private JButton btnNewButton_tailai;
	private JButton btnNewButton_xoaTrang;

	public TimKiemPhong_GUI() {
		ConnectDB.getInstance().connect();
		p_dao = new Phong_Dao();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH); 
		setBounds(0, 0, 1650, 1080);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		  
		JMenu mnNewMenu_menu = new JMenu("Nhân Viên");
		mnNewMenu_menu.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/user.png")));
		mnNewMenu_menu.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_menu.addActionListener(this);
		menuBar.add(mnNewMenu_menu);
		
		JMenuItem mntmNewMenuItem_upNV = new JMenuItem("Cập Nhập Nhân Viên");
		mntmNewMenuItem_upNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_upNV);
		
		JMenuItem mntmNewMenuItem_findNV = new JMenuItem("Tìm Kiếm Nhân Viên");
		mntmNewMenuItem_findNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_findNV);
		
		JMenuItem mntmNewMenuItem_tkNV = new JMenuItem("Tài Khoản");
		mntmNewMenuItem_tkNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/user4.png")));
		mntmNewMenuItem_tkNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_tkNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_tkNV);
		
		JMenuItem mntmNewMenuItem_cvNV = new JMenuItem("Chức Vụ");
		mntmNewMenuItem_cvNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_KH.png")));
		mntmNewMenuItem_cvNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_cvNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_cvNV);
		
		JMenu mnNewMenu_kh = new JMenu("Khách Hàng");
		mnNewMenu_kh.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/users.png")));
		mnNewMenu_kh.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_kh.addActionListener(this);
		menuBar.add(mnNewMenu_kh);
		
		JMenuItem mntmCpNhp_upKH = new JMenuItem("Cập Nhập Khách Hàng");
		mntmCpNhp_upKH.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmCpNhp_upKH.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmCpNhp_upKH.addActionListener(this);
		mnNewMenu_kh.add(mntmCpNhp_upKH);
		
		JMenuItem mntmNewMenuItem_findKH = new JMenuItem("Tìm Kiếm Khách Hàng");
		mntmNewMenuItem_findKH.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findKH.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findKH.addActionListener(this);
		mnNewMenu_kh.add(mntmNewMenuItem_findKH);
		
		JMenu mnNewMenu_dv = new JMenu("Dịch Vụ");
		mnNewMenu_dv.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_DV (5).png")));
		mnNewMenu_dv.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_dv.addActionListener(this);
		menuBar.add(mnNewMenu_dv);
		
		JMenuItem mntmNewMenuItem_upDV = new JMenuItem("Cập Nhập Dịch Vụ");
		mntmNewMenuItem_upDV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upDV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upDV.addActionListener(this);
		mnNewMenu_dv.add(mntmNewMenuItem_upDV);
		
		JMenuItem mntmNewMenuItem_findDV = new JMenuItem("Tìm Kiếm Dịch Vụ");
		mntmNewMenuItem_findDV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findDV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findDV.addActionListener(this);
		mnNewMenu_dv.add(mntmNewMenuItem_findDV);
		
		JMenuItem mntmNewMenuItem_loaiDV = new JMenuItem("Loại Dịch Vụ");
		mntmNewMenuItem_loaiDV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/food.png")));
		mntmNewMenuItem_loaiDV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_loaiDV.addActionListener(this);
		mnNewMenu_dv.add(mntmNewMenuItem_loaiDV);
		
		JMenu mnNewMenu_phong = new JMenu("Phòng");
		mnNewMenu_phong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/essentials-08.png")));
		mnNewMenu_phong.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_phong.addActionListener(this);
		menuBar.add(mnNewMenu_phong);
		
		JMenuItem mntmNewMenuItem_upPhong = new JMenuItem("Cập Nhập Phòng");
		mntmNewMenuItem_upPhong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upPhong.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upPhong.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_upPhong);
		
		JMenuItem mntmNewMenuItem_upLP = new JMenuItem("Cập Nhập Loại Phòng");
		mntmNewMenuItem_upLP.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upLP.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upLP.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_upLP);
		
		JMenuItem mntmNewMenuItem_findPhong = new JMenuItem("Tìm Kiếm Phòng");
		mntmNewMenuItem_findPhong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findPhong.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findPhong.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_findPhong);
		
		JMenuItem mntmNewMenuItem_datPhong = new JMenuItem("Đặt Phòng");
		mntmNewMenuItem_datPhong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/bell.png")));
		mntmNewMenuItem_datPhong.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_datPhong.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_datPhong);
		
		JMenu mnNewMenu_hd = new JMenu("Hoá Đơn");
		mnNewMenu_hd.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_HD.png")));
		mnNewMenu_hd.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_hd.addActionListener(this);
		menuBar.add(mnNewMenu_hd);
		
		JMenuItem mntmNewMenuItem_lapHD = new JMenuItem("Lập Hoá Đơn");
		mntmNewMenuItem_lapHD.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_ThanhToan.png")));
		mntmNewMenuItem_lapHD.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_lapHD.addActionListener(this);
		mnNewMenu_hd.add(mntmNewMenuItem_lapHD);
		
		JMenuItem mntmNewMenuItem_thanhToan = new JMenuItem("Thanh Toán");
		mntmNewMenuItem_thanhToan.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/print.png")));
		mntmNewMenuItem_thanhToan.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_thanhToan.addActionListener(this);
		mnNewMenu_hd.add(mntmNewMenuItem_thanhToan);
		
		JMenu mnNewMenu_thongKe = new JMenu("Thống Kê");
		mnNewMenu_thongKe.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_TK.png")));
		mnNewMenu_thongKe.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_thongKe.addActionListener(this);
		menuBar.add(mnNewMenu_thongKe);
		
		JMenuItem mntmNewMenuItem_tkDoanhThu = new JMenuItem("Thống Kê Doanh Thu");
		mntmNewMenuItem_tkDoanhThu.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_TK.png")));
		mntmNewMenuItem_tkDoanhThu.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_tkDoanhThu.addActionListener(this);
		mnNewMenu_thongKe.add(mntmNewMenuItem_tkDoanhThu);
		
		JMenu mnNewMenu = new JMenu("Log");
		mnNewMenu.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/enter.png")));
		mnNewMenu.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Đổi mật khẩu");
		mntmNewMenuItem.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/redo2.png")));
		mntmNewMenuItem.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Đăng Xuất");
		mntmNewMenuItem_1.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/exit.png")));
		mntmNewMenuItem_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem_1);
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TÌM KIẾM PHÒNG");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblNewLabel.setBounds(342, 0, 650, 74);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_tenPhong = new JLabel("Tên Phòng:");
		lblNewLabel_tenPhong.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_tenPhong.setBounds(276, 131, 86, 29);
		contentPane.add(lblNewLabel_tenPhong);
		
		JLabel lblNewLabel_loaiPhong = new JLabel("Loại Phòng:");
		lblNewLabel_loaiPhong.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_loaiPhong.setBounds(559, 131, 86, 29);
		contentPane.add(lblNewLabel_loaiPhong);
		
		JLabel lblNewLabel_tinhTrang = new JLabel("Tình Trạng:");
		lblNewLabel_tinhTrang.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_tinhTrang.setBounds(890, 131, 86, 29);
		contentPane.add(lblNewLabel_tinhTrang);
		
		textField_tenPhong = new JTextField();
		textField_tenPhong.setBounds(372, 135, 146, 26);
		contentPane.add(textField_tenPhong);
		textField_tenPhong.setColumns(10);
		
		 comboBox_loaiPhong = new JComboBox();
		comboBox_loaiPhong.setBounds(655, 133, 146, 29);
		comboBox_loaiPhong.addItem("-Chọn-");
		for(Phong p : p_dao.getallPhong()) {
			comboBox_loaiPhong.addItem(p.getLoaiPhong().getLoaiPhong());
		}
		contentPane.add(comboBox_loaiPhong);
		
		 comboBox_tinhTrang = new JComboBox();
		comboBox_tinhTrang.setBounds(986, 133, 146, 29);
		comboBox_tinhTrang.addItem("-Chọn-");
		comboBox_tinhTrang.addItem("Phòng trống");
		comboBox_tinhTrang.addItem("Phòng có Khách");
		contentPane.add(comboBox_tinhTrang);
		
		 btnNewButton_find = new JButton("Tìm Kiếm");
		btnNewButton_find.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_find.setBounds(541, 229, 134, 39);
		contentPane.add(btnNewButton_find);
		
		String [] headers = {"Mã Phòng", "Tên Phòng", "Giá Phòng", "Loại Phòng", "Tình Trạng"};
		tableModel=new DefaultTableModel(headers,0);
		JScrollPane scroll = new JScrollPane();
		scroll.setViewportView(table = new JTable(tableModel));
		table.setRowHeight(25);
		table.setAutoCreateRowSorter(true);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 331, 1520, 399);
		contentPane.add(scrollPane);
		
		JLabel lblNewLabel_2 = new JLabel("Danh sách Phòng:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 292, 151, 29);
		contentPane.add(lblNewLabel_2);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Th\u00F4ng Tin Ph\u00F2ng C\u1EA7n T\u00ECm", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		horizontalBox.setBounds(10, 84, 1520, 135);
		contentPane.add(horizontalBox);
		
		btnNewButton_xoaTrang = new JButton("Xóa Trắng");
		btnNewButton_xoaTrang.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_xoaTrang.setBounds(998, 229, 134, 39);
		contentPane.add(btnNewButton_find_1);
		
		btnNewButton_tailai = new JButton("Tải Lại");
		 btnNewButton_tailai.setFont(new Font("Tahoma", Font.PLAIN, 20));
		 btnNewButton_tailai.setBounds(681, 229, 134, 39);
		contentPane.add(btnNewButton_find_2);
		
		
		
		btnNewButton_find.addActionListener(this);
		btnNewButton_tailai.addActionListener(this);
		btnNewButton_xoaTrang.addActionListener(this);
		table.addMouseListener(this);
		DocDuLieuDatabaseVaoTable();
		this.setVisible(true);
	}
	
	private void DocDuLieuDatabaseVaoTable() {
		// TODO Auto-generated method stub
		Phong_Dao ds = new Phong_Dao();
		List<Phong> list = ds.getallPhong();
		for(Phong s : list) {
			String[] rowData = {s.getMaPhong(), s.getTenPhong(), s.getGiaPhong()+"", s.getLoaiPhong().getLoaiPhong(), s.getTinhTrang()};
			tableModel.addRow(rowData);
			}
		table.setModel(tableModel);
	}
	private void xoaTrang() {
		// TODO Auto-generated method stub
		textField_tenPhong.setText("");
		textField_tenPhong.requestFocus();
	}


	private void tailai() {
		// TODO Auto-generated method stub
		tableModel.setRowCount(0); 
		Phong_Dao ds = new Phong_Dao();
		List<Phong> list = ds.getallPhong();
		for(Phong s : list) {
			String[] rowData = {s.getMaPhong(), s.getTenPhong(), s.getGiaPhong()+"", s.getLoaiPhong().getLoaiPhong(), s.getTinhTrang()};
			tableModel.addRow(rowData);
			}
		table.setModel(tableModel);
	}
	//////////////
	private void timPhong(){
		// TODO Auto-generated method stub
		ResultSet rs = null;
		Connection connection = null;
		Statement  st = null;
		String ten = textField_tenPhong.getText();
		String loaiP = comboBox_loaiPhong.getSelectedItem().toString();
		String tt = comboBox_tinhTrang.getSelectedItem().toString();
		 try {
	        	connection = ConnectDB.getConnection();
	        	String sql = "select * from Phong ";
	        	String chon = "-Chọn-";
	        	if(ten.length()>0) {
	            	sql = sql + "where tenPhong like N'%" + ten + "%'";
	            }
	            else if(loaiP != chon) {
	            	sql = sql + "where loaiPhong like N'%" + loaiP + "%'";
	            }
	            else if(tt!=chon) {
	            	sql = sql + "where tinhTrang like N'%" + tt + "%'";
	            }
	        
	            
	            st = connection.createStatement();
	            rs = st.executeQuery(sql);
	            Vector data = null;
	            tableModel.setRowCount(0); 
	            
	            if (rs.isBeforeFirst() == false) {
	            	
	            	JOptionPane.showMessageDialog(btnNewButton, "Không tìm thấy Phong");
	            	return;
	            }
	            while(rs.next()) {
	            	data = new Vector();
	            	data.add(rs.getString(1));
	            	data.add(rs.getString(2));
	            	data.add(rs.getString(3));
	            	data.add(rs.getString(4));
	            	data.add(rs.getString(5));
	            	
	            	tableModel.addRow(data);
	            }
	            table.setModel(tableModel);
	            //xoaTrang();
	            
	        }catch (SQLException sqlException) {
	            sqlException.printStackTrace();
	        }
	}
	//////////////

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Cập Nhập Nhân Viên")) {
			dispose();
            new CapNhapNV_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Nhân Viên")) {
			dispose();
            new TimKiemNV_GUI();
        }
		if (e.getActionCommand().equals("Tài Khoản")) {
			dispose();
            new TaiKhoan_GUI();
        }
		if (e.getActionCommand().equals("Chức Vụ")) {
			dispose();
            new ChucVu_GUI();
        }
		////////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Cập Nhập Khách Hàng")) {
			dispose();
            new CapNhapKH_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Khách Hàng")) {
			dispose();
            new TimKiemKH_GUI();
        }
		///////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Cập Nhập Dịch Vụ")) {
			dispose();
            new CapNhapDV_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Dịch Vụ")) {
			dispose();
            new TimKiemDV_GUI();
        }
		if (e.getActionCommand().equals("Loại Dịch Vụ")) {
			dispose();
            new LoaiDichVu_GUI();
        }
		///////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Cập Nhập Phòng")) {
			dispose();
            new CapNhapPhong_GUI();
        }
		if (e.getActionCommand().equals("Cập Nhập Loại Phòng")) {
			dispose();
            new LoaiPhong_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Phòng")) {
			dispose();
            new TimKiemPhong_GUI();
        }
		if (e.getActionCommand().equals("Đặt Phòng")) {
			dispose();
            new DatPhong_GUI();
        }
		///////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Lập Hoá Đơn")) {
			dispose();
            new LapHoaDon_GUI();
        }
		if (e.getActionCommand().equals("Thống Kê Doanh Thu")) {
			dispose();
            new ThongKe_GUI();
        }
		Object o = e.getSource();
		if(o.equals(btnNewButton_find))
			timPhong();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

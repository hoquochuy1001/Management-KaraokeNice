package gui;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import javax.swing.JComboBox;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.border.BevelBorder;
import javax.swing.JTabbedPane;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;

import java.awt.Component;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import connectDB.ConnectDB;
import connectDB.ConnectLG;
import dao.ChucVu_Dao;
import dao.NhanVien_Dao;
import entity.ChucVu;
import entity.NhanVien;

public class TimKiemNV_GUI extends JFrame implements ActionListener, MouseListener{

	private JPanel contentPane;
	private JTextField textField_maNV;
	private JTextField textField_tenNV;
	private JTextField textField_ngaySinh;
	private JTextField textField_sdt;
	private JTable table;
	private NhanVien_Dao nv_dao;
	private ChucVu_Dao cv_dao;
	private DefaultTableModel tableModel;
	private JComboBox comboBox_chucVu;
	private JComboBox comboBox_gioiTinh;
	private JButton btnNewButton_find;
	private NhanVien_Dao ds;
	private Component btnNewButton;
	private JButton btnNewButton_f5;
	private JButton btnNewButton_xoatrang;

	
	public TimKiemNV_GUI() {
		
		ConnectDB.getInstance().connect();
		nv_dao = new NhanVien_Dao();
		cv_dao = new ChucVu_Dao();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH); 
		setBounds(0, 0, 1650, 1080);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		  
		JMenu mnNewMenu_menu = new JMenu("Nhân Viên");
		mnNewMenu_menu.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/user.png")));
		mnNewMenu_menu.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_menu.addActionListener(this);
		menuBar.add(mnNewMenu_menu);
		
		JMenuItem mntmNewMenuItem_upNV = new JMenuItem("Cập Nhập Nhân Viên");
		mntmNewMenuItem_upNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_upNV);
		
		JMenuItem mntmNewMenuItem_findNV = new JMenuItem("Tìm Kiếm Nhân Viên");
		mntmNewMenuItem_findNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_findNV);
		
		JMenuItem mntmNewMenuItem_tkNV = new JMenuItem("Tài Khoản");
		mntmNewMenuItem_tkNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/user4.png")));
		mntmNewMenuItem_tkNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_tkNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_tkNV);
		
		JMenuItem mntmNewMenuItem_cvNV = new JMenuItem("Chức Vụ");
		mntmNewMenuItem_cvNV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_KH.png")));
		mntmNewMenuItem_cvNV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_cvNV.addActionListener(this);
		mnNewMenu_menu.add(mntmNewMenuItem_cvNV);
		
		JMenu mnNewMenu_kh = new JMenu("Khách Hàng");
		mnNewMenu_kh.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/users.png")));
		mnNewMenu_kh.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_kh.addActionListener(this);
		menuBar.add(mnNewMenu_kh);
		
		JMenuItem mntmCpNhp_upKH = new JMenuItem("Cập Nhập Khách Hàng");
		mntmCpNhp_upKH.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmCpNhp_upKH.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmCpNhp_upKH.addActionListener(this);
		mnNewMenu_kh.add(mntmCpNhp_upKH);
		
		JMenuItem mntmNewMenuItem_findKH = new JMenuItem("Tìm Kiếm Khách Hàng");
		mntmNewMenuItem_findKH.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findKH.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findKH.addActionListener(this);
		mnNewMenu_kh.add(mntmNewMenuItem_findKH);
		
		JMenu mnNewMenu_dv = new JMenu("Dịch Vụ");
		mnNewMenu_dv.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_DV (5).png")));
		mnNewMenu_dv.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_dv.addActionListener(this);
		menuBar.add(mnNewMenu_dv);
		
		JMenuItem mntmNewMenuItem_upDV = new JMenuItem("Cập Nhập Dịch Vụ");
		mntmNewMenuItem_upDV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upDV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upDV.addActionListener(this);
		mnNewMenu_dv.add(mntmNewMenuItem_upDV);
		
		JMenuItem mntmNewMenuItem_findDV = new JMenuItem("Tìm Kiếm Dịch Vụ");
		mntmNewMenuItem_findDV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findDV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findDV.addActionListener(this);
		mnNewMenu_dv.add(mntmNewMenuItem_findDV);
		
		JMenuItem mntmNewMenuItem_loaiDV = new JMenuItem("Loại Dịch Vụ");
		mntmNewMenuItem_loaiDV.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/food.png")));
		mntmNewMenuItem_loaiDV.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_loaiDV.addActionListener(this);
		mnNewMenu_dv.add(mntmNewMenuItem_loaiDV);
		
		JMenu mnNewMenu_phong = new JMenu("Phòng");
		mnNewMenu_phong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/essentials-08.png")));
		mnNewMenu_phong.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_phong.addActionListener(this);
		menuBar.add(mnNewMenu_phong);
		
		JMenuItem mntmNewMenuItem_upPhong = new JMenuItem("Cập Nhập Phòng");
		mntmNewMenuItem_upPhong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upPhong.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upPhong.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_upPhong);
		
		JMenuItem mntmNewMenuItem_upLP = new JMenuItem("Cập Nhập Loại Phòng");
		mntmNewMenuItem_upLP.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/plus.png")));
		mntmNewMenuItem_upLP.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_upLP.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_upLP);
		
		JMenuItem mntmNewMenuItem_findPhong = new JMenuItem("Tìm Kiếm Phòng");
		mntmNewMenuItem_findPhong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/search.png")));
		mntmNewMenuItem_findPhong.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_findPhong.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_findPhong);
		
		JMenuItem mntmNewMenuItem_datPhong = new JMenuItem("Đặt Phòng");
		mntmNewMenuItem_datPhong.setIcon(new ImageIcon(Menu_GUI.class.getResource("/image/bell.png")));
		mntmNewMenuItem_datPhong.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_datPhong.addActionListener(this);
		mnNewMenu_phong.add(mntmNewMenuItem_datPhong);
		
		JMenu mnNewMenu_hd = new JMenu("Hoá Đơn");
		mnNewMenu_hd.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_HD.png")));
		mnNewMenu_hd.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_hd.addActionListener(this);
		menuBar.add(mnNewMenu_hd);
		
		JMenuItem mntmNewMenuItem_lapHD = new JMenuItem("Lập Hoá Đơn");
		mntmNewMenuItem_lapHD.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_ThanhToan.png")));
		mntmNewMenuItem_lapHD.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_lapHD.addActionListener(this);
		mnNewMenu_hd.add(mntmNewMenuItem_lapHD);
		
		
		
		JMenu mnNewMenu_thongKe = new JMenu("Thống Kê");
		mnNewMenu_thongKe.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_TK.png")));
		mnNewMenu_thongKe.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		mnNewMenu_thongKe.addActionListener(this);
		menuBar.add(mnNewMenu_thongKe);
		
		JMenuItem mntmNewMenuItem_tkDoanhThu = new JMenuItem("Thống Kê Doanh Thu");
		mntmNewMenuItem_tkDoanhThu.setIcon(new ImageIcon(Menu_GUI.class.getResource("/images/ic_TK.png")));
		mntmNewMenuItem_tkDoanhThu.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_tkDoanhThu.addActionListener(this);
		mnNewMenu_thongKe.add(mntmNewMenuItem_tkDoanhThu);
		
		
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TÌM KIẾM NHÂN VIÊN");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblNewLabel.setBounds(352, 10, 650, 74);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_maNV = new JLabel("Mã NV:");
		lblNewLabel_maNV.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_maNV.setBounds(246, 118, 58, 29);
		contentPane.add(lblNewLabel_maNV);
		
		JLabel lblNewLabel_tenNV = new JLabel("Tên NV:");
		lblNewLabel_tenNV.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_tenNV.setBounds(246, 172, 58, 29);
		contentPane.add(lblNewLabel_tenNV);
		
		JLabel lblNewLabel_ngaySinh = new JLabel("Ngày Sinh:");
		lblNewLabel_ngaySinh.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_ngaySinh.setBounds(581, 118, 74, 29);
		contentPane.add(lblNewLabel_ngaySinh);
		
		JLabel lblNewLabel_sdt = new JLabel("SĐT:");
		lblNewLabel_sdt.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_sdt.setBounds(581, 172, 74, 29);
		contentPane.add(lblNewLabel_sdt);
		
		JLabel lblNewLabel_gioiTinh = new JLabel("Giới Tính:");
		lblNewLabel_gioiTinh.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_gioiTinh.setBounds(1002, 118, 74, 29);
		contentPane.add(lblNewLabel_gioiTinh);
		
		JLabel lblNewLabel_chucVu = new JLabel("Chức Vụ:");
		lblNewLabel_chucVu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_chucVu.setBounds(1002, 172, 74, 29);
		contentPane.add(lblNewLabel_chucVu);
		
		textField_maNV = new JTextField();
		textField_maNV.setBounds(314, 122, 146, 26);
		contentPane.add(textField_maNV);
		textField_maNV.setColumns(10);
		
		textField_tenNV = new JTextField();
		textField_tenNV.setBounds(314, 176, 146, 26);
		contentPane.add(textField_tenNV);
		textField_tenNV.setColumns(10);
		
		textField_ngaySinh = new JTextField();
		textField_ngaySinh.setColumns(10);
		textField_ngaySinh.setBounds(665, 122, 146, 26);
		contentPane.add(textField_ngaySinh);
		
		textField_sdt = new JTextField();
		textField_sdt.setColumns(10);
		textField_sdt.setBounds(665, 176, 146, 26);
		contentPane.add(textField_sdt);
		
		comboBox_gioiTinh = new JComboBox();
		comboBox_gioiTinh.setEditable(true);
		comboBox_gioiTinh.addItem("-Chọn-");
		comboBox_gioiTinh.addItem("Nam");
		comboBox_gioiTinh.addItem("Nữ");
//		for(NhanVien nv : nv_dao.getalltbNhanVien()) {
//			comboBox_gioiTinh.addItem(nv.getGioiTinh());
//		}
		comboBox_gioiTinh.setBounds(1072, 120, 146, 29);
		contentPane.add(comboBox_gioiTinh);
		
		comboBox_chucVu = new JComboBox();
		comboBox_chucVu.setEditable(true);
		comboBox_chucVu.addItem("-Chọn-");
		for(ChucVu cv : cv_dao.getalltbChucVu()) {
			comboBox_chucVu.addItem(cv.getMaCV());
		}
		comboBox_chucVu.setBounds(1072, 174, 146, 29);
		contentPane.add(comboBox_chucVu);
		
		btnNewButton_find = new JButton("Tìm Kiếm");
		btnNewButton_find.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_find.setBounds(394, 236, 134, 39);
		contentPane.add(btnNewButton_find);
		
		String [] headers = {"Mã NV", "Tên NV","Ngày sinh","SĐT", "Giới tính", "Chức Vụ"};
		tableModel=new DefaultTableModel(headers,0);
		JScrollPane scroll = new JScrollPane();
		scroll.setViewportView(table = new JTable(tableModel));
		table.setRowHeight(25);
		table.setAutoCreateRowSorter(true);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 331, 1520, 391);
		contentPane.add(scrollPane);
		
		JLabel lblNewLabel_2 = new JLabel("Danh sách Tìm Kiếm:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 292, 151, 29);
		contentPane.add(lblNewLabel_2);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Th\u00F4ng Tin T\u00ECm Ki\u1EBFm", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		horizontalBox.setBounds(10, 91, 1520, 135);
		contentPane.add(horizontalBox);
		
		 btnNewButton_f5 = new JButton("Tải Lại");
		btnNewButton_f5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_f5.setBounds(652, 236, 134, 39);
		contentPane.add(btnNewButton_f5);
		
		 btnNewButton_xoatrang = new JButton("Xóa Trắng");
		btnNewButton_xoatrang.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_xoatrang.setBounds(906, 236, 134, 39);
		contentPane.add(btnNewButton_xoatrang);
		
		btnNewButton_find.addActionListener(this);
		btnNewButton_f5.addActionListener(this);
		btnNewButton_xoatrang.addActionListener(this);
		table.addMouseListener(this);
		DocDuLieuDatabaseVaoTable();
		this.setVisible(true);
	}

	private void DocDuLieuDatabaseVaoTable() {
		// TODO Auto-generated method stub
		NhanVien_Dao ds = new NhanVien_Dao();
		List<NhanVien> list = ds.getalltbNhanVien();
		for(NhanVien s : list) {
			String[] rowData = {s.getMaNV(), s.getTenNV(), new SimpleDateFormat("dd-MM-yyyy").format(s.getNgaysinh()), 
					s.getSdt(), s.getGioiTinh(), s.getChucvu().getMaCV()};
			tableModel.addRow(rowData);
			}
		table.setModel(tableModel);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Cập Nhập Nhân Viên")) {
			dispose();
            new CapNhapNV_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Nhân Viên")) {
			dispose();
            new TimKiemNV_GUI();
        }
		if (e.getActionCommand().equals("Tài Khoản")) {
			dispose();
            new TaiKhoan_GUI();
        }
		if (e.getActionCommand().equals("Chức Vụ")) {
			dispose();
            new ChucVu_GUI();
        }
		////////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Cập Nhập Khách Hàng")) {
			dispose();
            new CapNhapKH_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Khách Hàng")) {
			dispose();
            new TimKiemKH_GUI();
        }
		///////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Cập Nhập Dịch Vụ")) {
			dispose();
            new CapNhapDV_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Dịch Vụ")) {
			dispose();
            new TimKiemDV_GUI();
        }
		if (e.getActionCommand().equals("Loại Dịch Vụ")) {
			dispose();
            new LoaiDichVu_GUI();
        }
		///////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Cập Nhập Phòng")) {
			dispose();
            new CapNhapPhong_GUI();
        }
		if (e.getActionCommand().equals("Cập Nhập Loại Phòng")) {
			dispose();
            new LoaiPhong_GUI();
        }
		if (e.getActionCommand().equals("Tìm Kiếm Phòng")) {
			dispose();
            new TimKiemPhong_GUI();
        }
		if (e.getActionCommand().equals("Đặt Phòng")) {
			dispose();
            new DatPhong_GUI();
        }
		///////////////////////////////////////////////////////////////////////////
		if (e.getActionCommand().equals("Lập Hoá Đơn")) {
			dispose();
            new LapHoaDon_GUI();
        }
		if (e.getActionCommand().equals("Thống Kê Doanh Thu")) {
			dispose();
            new ThongKe_GUI();
        }
		Object o = e.getSource();
		if(o.equals(btnNewButton_find))
			timNV();
		if(o.equals(btnNewButton_f5))
			tailai();
		if(o.equals(btnNewButton_xoatrang))
			xoaTrang();
			
	}
	private void tailai() {
		// TODO Auto-generated method stub
		tableModel.setRowCount(0); 
		NhanVien_Dao ds = new NhanVien_Dao();
		List<NhanVien> list = ds.getalltbNhanVien();
		for(NhanVien s : list) {
			String[] rowData = {s.getMaNV(), s.getTenNV(), new SimpleDateFormat("dd-MM-yyyy").format(s.getNgaysinh()), 
					s.getSdt(), s.getGioiTinh(), s.getChucvu().getMaCV()};
			tableModel.addRow(rowData);
			}
		table.setModel(tableModel);
	}

	private void xoaTrang() {
		// TODO Auto-generated method stub
		textField_maNV.setText("");
		textField_tenNV.setText("");
		textField_ngaySinh.setText("");
		textField_sdt.setText("");
		textField_maNV.requestFocus();
	}
	private void timNV() {
		// TODO Auto-generated method stub
		ResultSet rs = null;
		Connection connection = null;
		Statement  st = null;
		String chon = "-Chọn-";
        String ma = textField_maNV.getText();
        String hoten = textField_tenNV.getText();
		
//		String ngaysinh = textField_ngaySinh.getText().trim();
//		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
//		LocalDate lcd = LocalDate.parse(ngaysinh, fmt);
//		Date ngaysinh1 = Date.valueOf(lcd);
		
		String sdt = textField_sdt.getText();
		String gioitinh = comboBox_gioiTinh.getSelectedItem().toString();
		String chucvu = comboBox_chucVu.getSelectedItem().toString();

		
        try {
        	connection = ConnectDB.getConnection();
        	String sql = "select * from NhanVien ";
          
        	
        	if(ma.length()>0) {
            	sql = sql + "where maNV like N'%" + ma + "%'";
            }
            else if(hoten.length()>0) {
            	sql = sql + "where tenNV like N'%" + hoten + "%'";
            }
            else if(sdt.length()>0) {
            	sql = sql + "where sdt like N'%" + sdt + "%'";
            }
            else if(gioitinh != chon) {
            	sql = sql + "where gioiTinh like N'%" + gioitinh + "%'";
            }  
            else if(chucvu != chon) {
            	sql = sql + "where maCV like N'%" + chucvu + "%'";
            }  
            
            st = connection.createStatement();
            rs = st.executeQuery(sql);
            Vector data = null;
            tableModel.setRowCount(0); 
            
            if (rs.isBeforeFirst() == false) {
            	
            	JOptionPane.showMessageDialog(btnNewButton, "Không tìm thấy Nhân Viên");
            	return;
            }
            while(rs.next()) {
            	data = new Vector();
            	data.add(rs.getString(1));
            	data.add(rs.getString(2));
            	data.add(rs.getString(3));
            	data.add(rs.getString(4));
            	data.add(rs.getString(5));
            	data.add(rs.getString(6));
            	
            	tableModel.addRow(data);
            }
            table.setModel(tableModel);
            xoaTrang();
            
        }catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		int row = table.getSelectedRow();
		textField_maNV.setText(tableModel.getValueAt(row, 0).toString());
		textField_tenNV.setText(tableModel.getValueAt(row, 1).toString());
		textField_ngaySinh.setText(tableModel.getValueAt(row, 2).toString());
		textField_sdt.setText(tableModel.getValueAt(row, 3).toString());
		((JComboBox) comboBox_gioiTinh).setSelectedItem(tableModel.getValueAt(row, 4).toString());
		((JComboBox) comboBox_chucVu).setSelectedItem(tableModel.getValueAt(row, 5).toString());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

package entity;

import java.sql.Date;

public class PhieuDatPhong {
	public int maPDP;
	private Phong maPhong;
	public Date tgDatPhong;
	private KhachHang maKH;
	private NhanVien maNV;
	public PhieuDatPhong() {
		super();
	}
	public PhieuDatPhong(int maPDP, Phong maPhong, Date tgDatPhong, KhachHang maKH, NhanVien maNV) {
		super();
		this.maPDP = maPDP;
		this.maPhong = maPhong;
		this.tgDatPhong = tgDatPhong;
		this.maKH = maKH;
		this.maNV = maNV;
	}
	public PhieuDatPhong(Phong maPhong, KhachHang maKH, NhanVien maNV) {
		super();
		this.maPhong = maPhong;
		this.maKH = maKH;
		this.maNV = maNV;
	}
	public int getMaPDP() {
		return maPDP;
	}
	public void setMaPDP(int maPDP) {
		this.maPDP = maPDP;
	}
	public Phong getMaPhong() {
		return maPhong;
	}
	public void setMaPhong(Phong maPhong) {
		this.maPhong = maPhong;
	}
	public Date getTgDatPhong() {
		return tgDatPhong;
	}
	public void setTgDatPhong(Date tgDatPhong) {
		this.tgDatPhong = tgDatPhong;
	}
	public KhachHang getMaKH() {
		return maKH;
	}
	public void setMaKH(KhachHang maKH) {
		this.maKH = maKH;
	}
	public NhanVien getMaNV() {
		return maNV;
	}
	public void setMaNV(NhanVien maNV) {
		this.maNV = maNV;
	}
	@Override
	public String toString() {
		return "PhieuDP2 [maPDP=" + maPDP + ", maPhong=" + maPhong + ", tgDatPhong=" + tgDatPhong + ", maKH=" + maKH
				+ ", maNV=" + maNV + "]";
	}
	
	
	
	
}

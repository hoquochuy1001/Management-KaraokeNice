package entity;

public class Phong {
	private String maPhong;
	private String tenPhong;
	private LoaiPhong loaiPhong;
	public double giaPhong;
	private String tinhTrang;
	
	public Phong() {
		super();
	}
	public Phong(String tenPhong, LoaiPhong loaiPhong, double giaPhong) {
		super();
		this.tenPhong = tenPhong;
		this.loaiPhong = loaiPhong;
		this.giaPhong = giaPhong;
	}
	public Phong(String maPhong, String tenPhong,double giaPhong, LoaiPhong loaiPhong,  String tinhTrang) {
		super();
		this.maPhong = maPhong;
		this.tenPhong = tenPhong;
		this.loaiPhong = loaiPhong;
		this.giaPhong = giaPhong;
		this.tinhTrang = tinhTrang;
	}
	public String getMaPhong() {
		return maPhong;
	}
	public void setMaPhong(String maPhong) {
		this.maPhong = maPhong;
	}
	public String getTenPhong() {
		return tenPhong;
	}
	public void setTenPhong(String tenPhong) {
		this.tenPhong = tenPhong;
	}
	public LoaiPhong getLoaiPhong() {
		return loaiPhong;
	}
	public void setLoaiPhong(LoaiPhong loaiPhong) {
		this.loaiPhong = loaiPhong;
	}
	public double getGiaPhong() {
		return giaPhong;
	}
	public void setGiaPhong(double giaPhong) {
		this.giaPhong = giaPhong;
	}
	public String getTinhTrang() {
		return tinhTrang;
	}
	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}
	@Override
	public String toString() {
		return "Phong [maPhong=" + maPhong + ", tenPhong=" + tenPhong + ", giaPhong=" + giaPhong + ", loaiPhong="
				+ loaiPhong + ", tinhTrang=" + tinhTrang + "]";
	}
	
	
}

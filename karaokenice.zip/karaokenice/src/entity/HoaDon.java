package entity;

import java.sql.Date;
//import java.util.*;
public class HoaDon {
	 int MaHD;
	 String SoHoaDon;
	 Date NgayTao;
	 String maNV;
	 String maKH;
	 double TongTien;
	 String GhiChu;
	public int getMaHD() {
		return MaHD;
	}
	public void setMaHD(int maHD) {
		MaHD = maHD;
	}
	public String getSoHoaDon() {
		return SoHoaDon;
	}
	public void setSoHoaDon(String soHoaDon) {
		SoHoaDon = soHoaDon;
	}
	public Date getNgayTao() {
		return NgayTao;
	}
	public void setNgayTao(Date ngayTao) {
		NgayTao = ngayTao;
	}
	public String getMaNV() {
		return maNV;
	}
	public void setMaNV(String maNV) {
		this.maNV = maNV;
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public double getTongTien() {
		return TongTien;
	}
	public void setTongTien(double tongTien) {
		TongTien = tongTien;
	}
	public String getGhiChu() {
		return GhiChu;
	}
	public void setGhiChu(String ghiChu) {
		GhiChu = ghiChu;
	}
	 
	
	
}

package entity;

public class KhachHang {
	private String maKH;
	private String tenKH;
	private String cmnd;
	private String sdt;
	
	public KhachHang() {
		super();
	}
	public KhachHang(String maKH) {
		super();
		this.maKH = maKH;
	}
	
//	public KhachHang(String tenKH) {
//		super();
//		this.tenKH = tenKH;
//	}
	public KhachHang(String maKH, String tenKH, String cmnd, String sdt) {
		super();
		this.maKH = maKH;
		this.tenKH = tenKH;
		this.cmnd = cmnd;
		this.sdt = sdt;
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public String getCmnd() {
		return cmnd;
	}
	public void setCmnd(String cmnd) {
		this.cmnd = cmnd;
	}
	public String getSdt() {
		return sdt;
	}
	public void setSdt(String sdt) {
		this.sdt = sdt;
	}
	@Override
	public String toString() {
		return "KhachHang [maKH=" + maKH + ", tenKH=" + tenKH + ", cmnd=" + cmnd + ", sdt=" + sdt + "]";
	}
	
	
}

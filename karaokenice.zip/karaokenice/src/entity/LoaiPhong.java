package entity;

public class LoaiPhong {
	private String loaiPhong;

	public LoaiPhong() {
		super();
	}

	public LoaiPhong(String loaiPhong) {
		super();
		this.loaiPhong = loaiPhong;
	}

	public String getLoaiPhong() {
		return loaiPhong;
	}

	public void setLoaiPhong(String loaiPhong) {
		this.loaiPhong = loaiPhong;
	}

	@Override
	public String toString() {
		return "LoaiPhong [loaiPhong=" + loaiPhong + "]";
	}
	
	
}

package entity;

import java.sql.Date;

public class NhanVien {
	private String maNV;
	private String tenNV;
	private Date ngaySinh;
	private String sdt;
	private String gioiTinh;
	private ChucVu chucvu;
	
	public NhanVien(String maNV) {
		super();
		this.maNV = maNV;
	}

	public NhanVien(String maNV, String tenNV, Date ngaysinh, String sdt, String gioiTinh, ChucVu chucvu) {
		super();
		this.maNV = maNV;
		this.tenNV = tenNV;
		this.ngaySinh = ngaysinh;
		this.sdt = sdt;
		this.gioiTinh = gioiTinh;
		this.chucvu = chucvu;
	}

	public NhanVien() {
		super();
	}

	public String getMaNV() {
		return maNV;
	}

	public void setMaNV(String maNV) {
		this.maNV = maNV;
	}

	public String getTenNV() {
		return tenNV;
	}

	public void setTenNV(String tenNV) {
		this.tenNV = tenNV;
	}

	public Date getNgaysinh() {
		return ngaySinh;
	}

	public void setNgaysinh(Date ngaysinh) {
		this.ngaySinh = ngaysinh;
	}

	public String getSdt() {
		return sdt;
	}

	public void setSdt(String sdt) {
		this.sdt = sdt;
	}

	public String getGioiTinh() {
		return gioiTinh;
	}

	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}

	public ChucVu getChucvu() {
		return chucvu;
	}

	public void setChucvu(ChucVu chucvu) {
		this.chucvu = chucvu;
	}

	@Override
	public String toString() {
		return "NhanVien [maNV=" + maNV + ", tenNV=" + tenNV + ", ngaysinh=" + ngaySinh + ", sdt=" + sdt + ", gioiTinh="
				+ gioiTinh + ", chucvu=" + chucvu + "]";
	}
}

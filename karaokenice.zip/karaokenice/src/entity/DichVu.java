package entity;

public class DichVu {
	private String maDV;
	private String tenDV;
	private String donViTinh;
	private double giaDV;
	private LoaiDichVu dv;
	public DichVu() {
		super();
	}
	public DichVu(String maDV, String tenDV, String donViTinh, double giaDV, LoaiDichVu dv) {
		super();
		this.maDV = maDV;
		this.tenDV = tenDV;
		this.donViTinh = donViTinh;
		this.giaDV = giaDV;
		this.dv = dv;
	}
	public String getMaDV() {
		return maDV;
	}
	public void setMaDV(String maDV) {
		this.maDV = maDV;
	}
	public String getTenDV() {
		return tenDV;
	}
	public void setTenDV(String tenDV) {
		this.tenDV = tenDV;
	}
	public String getDonViTinh() {
		return donViTinh;
	}
	public void setDonViTinh(String donViTinh) {
		this.donViTinh = donViTinh;
	}
	public double getGiaDV() {
		return giaDV;
	}
	public void setGiaDV(double giaDV) {
		this.giaDV = giaDV;
	}
	public LoaiDichVu getDv() {
		return dv;
	}
	public void setDv(LoaiDichVu dv) {
		this.dv = dv;
	}
	@Override
	public String toString() {
		return "DichVu [maDV=" + maDV + ", tenDV=" + tenDV + ", donViTinh=" + donViTinh + ", giaDV=" + giaDV + ", dv="
				+ dv + "]";
	}
	
}

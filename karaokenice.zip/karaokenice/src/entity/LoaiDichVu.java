package entity;

public class LoaiDichVu {
	private String loaiDV;

	public LoaiDichVu() {
		super();
	}

	public LoaiDichVu(String loaiDV) {
		super();
		this.loaiDV = loaiDV;
	}

	public String getLoaiDV() {
		return loaiDV;
	}

	public void setLoaiDV(String loaiDV) {
		this.loaiDV = loaiDV;
	}

	@Override
	public String toString() {
		return "LoaiDichVu [loaiDV=" + loaiDV + "]";
	}
}

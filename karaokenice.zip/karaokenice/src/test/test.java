package test;

import gui.Menu_GUI;

public class test {
	public static void main(String[] args) {
		new Menu_GUI();
	}
}

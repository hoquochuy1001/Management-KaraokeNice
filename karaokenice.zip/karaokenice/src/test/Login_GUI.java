package test;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import connectDB.ConnectDB;
import connectDB.ConnectLG;
import gui.Menu_GUI;
import javax.swing.ImageIcon;

public class Login_GUI extends JFrame {
    private static final long serialVersionUID = 1L;


    private JTextField textField;
    private JPasswordField passwordField;
    private JButton btnNewButton;
    private JLabel label;
    private JPanel contentPane;
    
    public static void main(String[] args) {
		new Login_GUI();
    }
    
    public Login_GUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 200, 609, 475);
        setResizable(false);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Login");
        lblNewLabel.setForeground(Color.ORANGE);
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 46));
        lblNewLabel.setBounds(213, 0, 273, 93);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBackground(Color.LIGHT_GRAY);
        textField.setFont(new Font("Tahoma", Font.PLAIN, 32));
        textField.setBounds(213, 120, 281, 68);
        contentPane.add(textField);
        textField.setColumns(10);
        textField.setText("TK001");

        passwordField = new JPasswordField();
        passwordField.setBackground(Color.LIGHT_GRAY);
        passwordField.setFont(new Font("Tahoma", Font.PLAIN, 32));
        passwordField.setBounds(213, 238, 281, 68);
        contentPane.add(passwordField);

        JLabel lblUsername = new JLabel("Username");
        lblUsername.setIcon(new ImageIcon(Login_GUI.class.getResource("/image/login.png")));
        lblUsername.setBackground(Color.BLACK);
        lblUsername.setForeground(Color.YELLOW);
        lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 31));
        lblUsername.setBounds(10, 128, 193, 52);
        contentPane.add(lblUsername);

        JLabel lblPassword = new JLabel("Password");
        lblPassword.setIcon(new ImageIcon(Login_GUI.class.getResource("/image/pass.png")));
        lblPassword.setForeground(Color.YELLOW);
        lblPassword.setBackground(Color.CYAN);
        lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 31));
        lblPassword.setBounds(10, 246, 193, 52);
        contentPane.add(lblPassword);

        btnNewButton = new JButton("Login");
        btnNewButton.setBackground(Color.LIGHT_GRAY);
        btnNewButton.setForeground(Color.YELLOW);
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 26));
        btnNewButton.setBounds(203, 373, 162, 73);
        btnNewButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String userName = textField.getText();
                String password = passwordField.getText();
                try {
                    Connection connection = ConnectLG.getConnection();

                    PreparedStatement st = connection
                            .prepareStatement("Select tenTK,matKhau from TaiKhoan where tenTK=? and matKhau=?");

                    st.setString(1, userName);
                    st.setString(2, password);
                    ResultSet rs = st.executeQuery();
                    if (rs.next()) {
                        dispose();
                        Menu_GUI ah = new Menu_GUI();
                        ah.setTitle("MENU");
                        ah.setVisible(true);
                        JOptionPane.showMessageDialog(btnNewButton, "Bạn đã đăng nhập thành công <3");
                    } else {
                        JOptionPane.showMessageDialog(btnNewButton, "User hoặc password sai!");
                    }
                } catch (SQLException sqlException) {
                    sqlException.printStackTrace();
                }
            }
        });

        contentPane.add(btnNewButton);

        label = new JLabel("");
        label.setIcon(new ImageIcon(Login_GUI.class.getResource("/image/background.jpg")));
        label.setBackground(Color.CYAN);
        label.setBounds(0, -61, 1008, 562);
        contentPane.add(label);
        
        this.setVisible(true);
    }
}
